// CameraTest.tsx
import { useEffect, useRef, useState } from "react";

export default function CameraTest() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [streaming, setStreaming] = useState(false);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setStreaming(true);
        console.log("Camera started.");
      }
    } catch (err) {
      console.error("Failed to access camera:", err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((track) => track.stop());
      videoRef.current.srcObject = null;
      setStreaming(false);
      console.log("Camera stopped.");
    }
  };

  return (
    <div className="flex flex-col items-center p-4 gap-4">
      <video ref={videoRef} autoPlay playsInline className="w-full max-w-md rounded-md border shadow" />
      <div className="flex gap-4">
        <button
          onClick={startCamera}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
        >
          Start Camera
        </button>
        <button
          onClick={stopCamera}
          className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
        >
          Stop Camera
        </button>
      </div>
      {streaming ? <p className="text-green-600">Streaming...</p> : <p className="text-red-600">Not streaming</p>}
    </div>
  );
}
