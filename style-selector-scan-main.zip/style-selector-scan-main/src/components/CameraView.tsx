import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Camera, RotateCcw, AlertCircle, CheckCircle, X, Settings } from 'lucide-react';
import { useCamera } from '@/hooks/useCamera';
import { useToast } from '@/hooks/use-toast';

interface CameraViewProps {
  onCapture: (imageData: string) => void;
  onError?: (error: string) => void;
  onCancel?: () => void;
  capturePrompt?: string;
  className?: string;
}

export function CameraView({ 
  onCapture, 
  onError, 
  onCancel, 
  capturePrompt = "Position clothing item in the frame",
  className = ""
}: CameraViewProps) {
  const [showPermissionHelp, setShowPermissionHelp] = useState(false);
  const { toast } = useToast();
  
  const {
    cameraState,
    videoRef,
    startCamera,
    stopCamera,
    capturePhoto,
    requestPermission,
    clearError,
  } = useCamera();

  useEffect(() => {
    // Auto-start camera when component mounts
    startCamera();
    
    return () => {
      stopCamera();
    };
  }, [startCamera, stopCamera]);

  const handleCapture = () => {
    const imageData = capturePhoto();
    if (imageData) {
      onCapture(imageData);
      toast({
        title: "Photo captured!",
        description: "Processing clothing colors...",
      });
    } else {
      const error = "Failed to capture photo";
      onError?.(error);
      toast({
        title: "Capture failed",
        description: error,
        variant: "destructive",
      });
    }
  };

  const handleRetry = () => {
    clearError();
    startCamera();
  };

  const handlePermissionRequest = async () => {
    const granted = await requestPermission();
    if (granted) {
      setShowPermissionHelp(false);
      startCamera();
    } else {
      setShowPermissionHelp(true);
    }
  };

  // Debug info (only in development)
  const showDebug = process.env.NODE_ENV === 'development';

  if (cameraState.error && !cameraState.hasPermission) {
    return (
      <Card className={`w-full max-w-md mx-auto ${className}`}>
        <CardContent className="p-6 text-center space-y-4">
          <div className="flex justify-center">
            <AlertCircle className="w-16 h-16 text-destructive" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">Camera Access Required</h3>
            <p className="text-sm text-muted-foreground">
              StyleScan needs camera access to analyze your clothing colors.
            </p>
          </div>

          <div className="bg-muted p-4 rounded-lg text-left">
            <p className="text-sm font-medium mb-2">To enable camera access:</p>
            <ul className="text-xs space-y-1 text-muted-foreground">
              <li>• Click the camera icon in your browser's address bar</li>
              <li>• Select "Allow" when prompted</li>
              <li>• Refresh the page if needed</li>
            </ul>
          </div>

          <div className="flex gap-2 justify-center">
            <Button onClick={handlePermissionRequest} variant="default">
              <Camera className="w-4 h-4 mr-2" />
              Grant Access
            </Button>
            {onCancel && (
              <Button onClick={onCancel} variant="outline">
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
            )}
          </div>

          {showPermissionHelp && (
            <div className="text-xs text-muted-foreground mt-4">
              Still having trouble? Try refreshing the page or check your browser settings.
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  if (cameraState.error) {
    return (
      <Card className={`w-full max-w-md mx-auto ${className}`}>
        <CardContent className="p-6 text-center space-y-4">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto" />
          <div>
            <h3 className="text-lg font-semibold mb-2">Camera Error</h3>
            <p className="text-sm text-muted-foreground">{cameraState.error}</p>
          </div>
          <div className="flex gap-2 justify-center">
            <Button onClick={handleRetry} variant="default">
              <RotateCcw className="w-4 h-4 mr-2" />
              Retry
            </Button>
            {onCancel && (
              <Button onClick={onCancel} variant="outline">
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`relative w-full max-w-2xl mx-auto ${className}`}>
      {/* Camera viewport */}
      <div className="relative aspect-[4/3] bg-black rounded-lg overflow-hidden">
        {cameraState.isLoading && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-10">
            <div className="text-center space-y-4">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-white text-sm">Starting camera...</p>
            </div>
          </div>
        )}

        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          playsInline
          muted
          autoPlay
        />

        {/* Overlay guide */}
        {cameraState.isActive && (
          <div className="absolute inset-0 pointer-events-none">
            {/* Frame guide */}
            <div className="absolute inset-8 border-2 border-white/50 rounded-lg">
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
                <Badge variant="secondary" className="bg-black/70 text-white">
                  {capturePrompt}
                </Badge>
              </div>
            </div>

            {/* Corner guides */}
            <div className="absolute top-8 left-8 w-6 h-6 border-l-4 border-t-4 border-primary rounded-tl-lg" />
            <div className="absolute top-8 right-8 w-6 h-6 border-r-4 border-t-4 border-primary rounded-tr-lg" />
            <div className="absolute bottom-8 left-8 w-6 h-6 border-l-4 border-b-4 border-primary rounded-bl-lg" />
            <div className="absolute bottom-8 right-8 w-6 h-6 border-r-4 border-b-4 border-primary rounded-br-lg" />
          </div>
        )}

        {/* Status indicator */}
        <div className="absolute top-4 right-4">
          {cameraState.isActive ? (
            <Badge variant="default" className="bg-green-500/90">
              <CheckCircle className="w-3 h-3 mr-1" />
              Live
            </Badge>
          ) : (
            <Badge variant="destructive">
              <AlertCircle className="w-3 h-3 mr-1" />
              Offline
            </Badge>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex justify-center items-center gap-4 mt-6">
        {onCancel && (
          <Button
            onClick={onCancel}
            variant="outline"
            size="lg"
            className="rounded-full"
          >
            <X className="w-5 h-5" />
          </Button>
        )}

        <Button
          onClick={handleCapture}
          disabled={!cameraState.isActive}
          size="lg"
          className="rounded-full w-16 h-16 p-0"
          variant="default"
        >
          <Camera className="w-8 h-8" />
        </Button>

        <Button
          onClick={handleRetry}
          variant="outline"
          size="lg"
          className="rounded-full"
        >
          <RotateCcw className="w-5 h-5" />
        </Button>
      </div>

      {/* Debug panel (development only) */}
      {showDebug && (
        <Card className="mt-4 border-dashed">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Settings className="w-4 h-4" />
              <span className="text-sm font-medium">Debug Info</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>Status: {cameraState.isActive ? 'Active' : 'Inactive'}</div>
              <div>Loading: {cameraState.isLoading ? 'Yes' : 'No'}</div>
              <div>Permission: {cameraState.hasPermission ? 'Granted' : 'Denied'}</div>
              <div>Stream: {cameraState.stream ? 'Connected' : 'None'}</div>
            </div>
            {cameraState.stream && (
              <div className="mt-2 text-xs">
                Tracks: {cameraState.stream.getVideoTracks().length}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}