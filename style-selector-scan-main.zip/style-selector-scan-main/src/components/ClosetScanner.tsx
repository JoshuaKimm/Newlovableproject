import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Shirt, ShirtIcon, Zap, Check, ArrowRight, SkipForward, HardHat, FootprintsIcon, X } from "lucide-react";
import { StylePreference, ClothingType, ScannedItem } from "@/pages/Index";
import { extractColorsFromImage } from "@/lib/colorExtraction";
import { useToast } from "@/hooks/use-toast";
import { CameraView } from "@/components/CameraView";
import { addScannedItem } from "@/utils/storage";

interface ClosetScannerProps {
  selectedStyles: StylePreference[];
  currentScanType: ClothingType;
  onCurrentScanTypeChange: (type: ClothingType) => void;
  onItemScanned: (item: ScannedItem) => void;
  onComplete: () => void;
  scannedItems: ScannedItem[];
}

const scanSteps = [
  { type: "shirts" as ClothingType, label: "Shirts", icon: Shirt, required: true },
  { type: "jackets" as ClothingType, label: "Jackets & Hoodies", icon: ShirtIcon, required: false },
  { type: "pants" as ClothingType, label: "Pants", icon: Zap, required: true },
  { type: "shoes" as ClothingType, label: "Shoes", icon: FootprintsIcon, required: false },
  { type: "hats" as ClothingType, label: "Hats & Accessories", icon: HardHat, required: false }
];

export function ClosetScanner({ 
  selectedStyles, 
  currentScanType, 
  onCurrentScanTypeChange,
  onItemScanned, 
  onComplete,
  scannedItems 
}: ClosetScannerProps) {
  const [showCamera, setShowCamera] = useState(false);
  const { toast } = useToast();

  const currentStepIndex = scanSteps.findIndex(step => step.type === currentScanType);
  const progress = ((currentStepIndex + 1) / scanSteps.length) * 100;
  
  const itemsForCurrentType = scannedItems.filter(item => item.type === currentScanType);
  const currentStep = scanSteps[currentStepIndex];

  const handleCameraCapture = useCallback(async (imageDataUrl: string) => {
    try {
      const colors = await extractColorsFromImage(imageDataUrl);
      
      const newItem: ScannedItem = {
        id: `${currentScanType}_${Date.now()}`,
        type: currentScanType,
        dominantColor: colors.dominant,
        colorPalette: colors.palette,
        image: imageDataUrl
      };

      // Save to storage and add to list
      addScannedItem(newItem);
      onItemScanned(newItem);
      
      toast({
        title: "Item Scanned!",
        description: `${currentScanType.slice(0, -1)} added to your closet.`,
      });

      setShowCamera(false);
    } catch (error) {
      console.error("Error processing image:", error);
      toast({
        title: "Processing Error",
        description: "Failed to analyze image colors. Please try again.",
        variant: "destructive",
      });
    }
  }, [currentScanType, onItemScanned, toast]);

  const handleNext = () => {
    if (currentStepIndex < scanSteps.length - 1) {
      onCurrentScanTypeChange(scanSteps[currentStepIndex + 1].type);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    if (!currentStep.required) {
      handleNext();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      <div className="container mx-auto px-4 py-8">
        {/* Progress Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-3xl font-bold text-primary-foreground">
              Scan Your {currentStep.label}
            </h2>
            <Badge variant="secondary">
              Step {currentStepIndex + 1} of {scanSteps.length}
            </Badge>
          </div>
          
          <Progress value={progress} className="h-2 mb-4" />
          
          {/* Step indicators */}
          <div className="flex gap-4 justify-center">
            {scanSteps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = index === currentStepIndex;
              const isCompleted = index < currentStepIndex || scannedItems.some(item => item.type === step.type);
              
              return (
                <div key={step.type} className="flex items-center gap-2">
                  <div className={`p-2 rounded-full flex items-center gap-2 ${
                    isActive 
                      ? "bg-primary text-primary-foreground" 
                      : isCompleted 
                      ? "bg-green-500 text-white" 
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {isCompleted && index < currentStepIndex ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <StepIcon className="w-4 h-4" />
                    )}
                    <span className="text-sm font-medium">{step.label}</span>
                  </div>
                  {index < scanSteps.length - 1 && (
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <Card className="max-w-4xl mx-auto">
          <CardContent className="p-6">
            {showCamera ? (
              <CameraView
                onCapture={handleCameraCapture}
                onCancel={() => setShowCamera(false)}
                capturePrompt={`Position ${currentStep.label.toLowerCase()} in frame`}
                className="w-full"
              />
            ) : (
              <div className="text-center space-y-6">
                <Badge variant="outline" className="text-sm px-4 py-2">
                  Step {currentStepIndex + 1} of {scanSteps.length}
                </Badge>
                
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <currentStep.icon className="w-16 h-16 text-primary" />
                  </div>
                  
                  <div>
                    <h2 className="text-2xl font-bold mb-2">Scan Your {currentStep.label}</h2>
                    <p className="text-muted-foreground">
                      Point your camera at individual {currentStep.label.toLowerCase()} to analyze their colors.
                      Make sure the clothing is well-lit and fills most of the frame.
                    </p>
                  </div>

                  {itemsForCurrentType.length > 0 && (
                    <div className="bg-muted p-4 rounded-lg">
                      <p className="text-sm font-medium mb-2">
                        Scanned {itemsForCurrentType.length} {currentStep.label.toLowerCase()}:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {itemsForCurrentType.map((item, index) => (
                          <div key={item.id} className="flex items-center gap-2 bg-background px-3 py-1 rounded-full">
                            <div 
                              className="w-4 h-4 rounded-full border-2 border-background"
                              style={{ backgroundColor: item.dominantColor }}
                            />
                            <span className="text-xs">{currentStep.label.slice(0, -1)} {index + 1}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    variant="default"
                    size="lg"
                    onClick={() => setShowCamera(true)}
                    className="group"
                  >
                    <currentStep.icon className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                    {itemsForCurrentType.length === 0 ? `Scan ${currentStep.label}` : `Scan Another`}
                  </Button>

                  {!currentStep.required && (
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={handleSkip}
                    >
                      <SkipForward className="w-4 h-4 mr-2" />
                      Skip {currentStep.label}
                    </Button>
                  )}

                  {(currentStep.required && itemsForCurrentType.length > 0) || 
                   (!currentStep.required && itemsForCurrentType.length >= 0) ? (
                    <Button
                      variant="hero"
                      size="lg"
                      onClick={handleNext}
                    >
                      {currentStepIndex === scanSteps.length - 1 ? "Complete" : "Next Step"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : null}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}