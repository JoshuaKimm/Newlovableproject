import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, RefreshCw, ArrowLeft, Heart, Star } from "lucide-react";
import { StylePreference, ScannedItem } from "@/pages/Index";
import { generateOutfitRecommendations } from "@/lib/outfitGenerator";

interface OutfitRecommendationsProps {
  scannedItems: ScannedItem[];
  selectedStyles: StylePreference[];
  onReset: () => void;
  onRescan: () => void;
}

export function OutfitRecommendations({ 
  scannedItems, 
  selectedStyles, 
  onReset, 
  onRescan 
}: OutfitRecommendationsProps) {
  const recommendations = generateOutfitRecommendations(scannedItems, selectedStyles);
  
  const groupedItems = {
    shirts: scannedItems.filter(item => item.type === 'shirts'),
    jackets: scannedItems.filter(item => item.type === 'jackets'),
    pants: scannedItems.filter(item => item.type === 'pants')
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Sparkles className="w-8 h-8 text-primary-glow" />
          <h2 className="text-4xl font-bold text-primary-foreground">
            Your Perfect Outfits
          </h2>
        </div>
        <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
          Based on your {scannedItems.length} scanned items and {selectedStyles.join(', ')} style preferences
        </p>
      </div>

      {/* Style Preferences */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {selectedStyles.map(style => (
          <Badge key={style} variant="secondary" className="px-3 py-1">
            {style}
          </Badge>
        ))}
      </div>

      {/* Outfit Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {recommendations.map((outfit, index) => (
          <Card key={index} className="overflow-hidden hover:shadow-glow transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-500 fill-current" />
                  {outfit.name}
                </CardTitle>
                <Badge variant="outline" className="text-xs">
                  {Math.round(outfit.matchScore * 100)}% match
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{outfit.description}</p>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Outfit Preview */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {outfit.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="relative">
                    <img 
                      src={item.image} 
                      alt={`${item.type} item`}
                      className="w-full aspect-square object-cover rounded-lg"
                    />
                    <div className="absolute top-1 right-1 w-4 h-4 rounded-full border-2 border-white shadow-sm"
                         style={{ backgroundColor: item.dominantColor }} />
                  </div>
                ))}
              </div>

              {/* Color Harmony */}
              <div>
                <h4 className="text-sm font-medium mb-2">Color Harmony</h4>
                <div className="flex gap-1">
                  {outfit.colorHarmony.map((color, colorIndex) => (
                    <div
                      key={colorIndex}
                      className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>

              {/* Style Tags */}
              <div className="flex flex-wrap gap-1">
                {outfit.tags.map(tag => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>

              {/* Like Button */}
              <Button variant="ghost" size="sm" className="w-full group">
                <Heart className="w-4 h-4 mr-2 group-hover:fill-current group-hover:text-red-500 transition-colors" />
                Save Outfit
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Scanned Items Summary */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-xl text-center">Your Scanned Closet</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.entries(groupedItems).map(([category, items]) => (
              <div key={category}>
                <h4 className="font-medium mb-3 capitalize">{category} ({items.length})</h4>
                <div className="grid grid-cols-4 gap-2">
                  {items.map((item, index) => (
                    <div key={item.id} className="relative">
                      <img 
                        src={item.image} 
                        alt={`${category} item`}
                        className="w-full aspect-square object-cover rounded"
                      />
                      <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full border border-white"
                           style={{ backgroundColor: item.dominantColor }} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button variant="outline" onClick={onRescan} className="min-w-40">
          <RefreshCw className="w-4 h-4 mr-2" />
          Scan More Items
        </Button>
        
        <Button variant="hero" onClick={onReset} className="min-w-40">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Start Over
        </Button>
      </div>
    </div>
  );
}