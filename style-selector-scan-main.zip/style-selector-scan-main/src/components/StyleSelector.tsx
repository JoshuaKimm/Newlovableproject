import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { StylePreference } from "@/pages/Index";
import { Sparkles, Heart, Briefcase, Zap, Palette, Camera, Star, Crown, Flame, Moon } from "lucide-react";

interface StyleSelectorProps {
  onStylesSelected: (styles: StylePreference[]) => void;
}

const styleOptions = [
  { id: "minimalist", label: "Minimalist", description: "Clean, simple, understated", icon: Sparkles },
  { id: "boho", label: "Boho", description: "Free-spirited, earthy, flowing", icon: Heart },
  { id: "preppy", label: "Preppy", description: "Classic, polished, collegiate", icon: Briefcase },
  { id: "streetwear", label: "Streetwear", description: "Urban, casual, trendy", icon: Zap },
  { id: "vintage", label: "Vintage", description: "Retro, timeless, classic", icon: Camera },
  { id: "gothic", label: "Gothic", description: "Dark, dramatic, bold", icon: Moon },
  { id: "romantic", label: "Romantic", description: "Soft, feminine, dreamy", icon: Heart },
  { id: "sporty", label: "Sporty", description: "Athletic, comfortable, active", icon: Zap },
  { id: "business", label: "Business", description: "Professional, sharp, confident", icon: Briefcase },
  { id: "casual", label: "Casual", description: "Relaxed, everyday, comfortable", icon: Sparkles },
  { id: "artsy", label: "Artsy", description: "Creative, unique, expressive", icon: Palette },
  { id: "punk", label: "Punk", description: "Rebellious, edgy, unconventional", icon: Flame },
  { id: "grunge", label: "Grunge", description: "Alternative, relaxed, lived-in", icon: Star },
  { id: "sophisticated", label: "Sophisticated", description: "Elegant, refined, luxurious", icon: Crown },
  { id: "edgy", label: "Edgy", description: "Bold, daring, modern", icon: Flame },
  { id: "feminine", label: "Feminine", description: "Graceful, delicate, pretty", icon: Heart },
  { id: "masculine", label: "Masculine", description: "Strong, structured, powerful", icon: Briefcase },
  { id: "avant-garde", label: "Avant-garde", description: "Experimental, artistic, futuristic", icon: Palette },
  { id: "retro", label: "Retro", description: "Nostalgic, throwback, vintage-inspired", icon: Camera },
  { id: "chic", label: "Chic", description: "Stylish, fashionable, effortless", icon: Crown }
] as const;

export function StyleSelector({ onStylesSelected }: StyleSelectorProps) {
  const [selectedStyles, setSelectedStyles] = useState<StylePreference[]>([]);

  const handleStyleToggle = (styleId: StylePreference) => {
    setSelectedStyles(prev => {
      if (prev.includes(styleId)) {
        return prev.filter(id => id !== styleId);
      }
      if (prev.length >= 5) {
        return prev; // Max 5 selections
      }
      return [...prev, styleId];
    });
  };

  const handleContinue = () => {
    if (selectedStyles.length > 0) {
      onStylesSelected(selectedStyles);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            What's Your Style?
          </h1>
          <p className="text-muted-foreground text-lg mb-2">
            Choose up to 5 styles that best represent your fashion preferences
          </p>
          <Badge variant="outline" className="text-sm">
            {selectedStyles.length}/5 selected
          </Badge>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-8">
          {styleOptions.map((style) => {
            const Icon = style.icon;
            const isSelected = selectedStyles.includes(style.id as StylePreference);
            const isDisabled = !isSelected && selectedStyles.length >= 5;

            return (
              <Card 
                key={style.id}
                className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                  isSelected 
                    ? 'ring-2 ring-primary bg-primary/5' 
                    : isDisabled 
                    ? 'opacity-50 cursor-not-allowed'
                    : 'hover:shadow-lg'
                }`}
                onClick={() => !isDisabled && handleStyleToggle(style.id as StylePreference)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full ${
                      isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-sm font-semibold">{style.label}</CardTitle>
                    </div>
                    <Checkbox 
                      checked={isSelected}
                      disabled={isDisabled}
                      className="pointer-events-none"
                    />
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-xs text-muted-foreground">{style.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {selectedStyles.length > 0 && (
          <div className="text-center">
            <div className="mb-4">
              <p className="text-sm text-muted-foreground mb-2">Selected styles:</p>
              <div className="flex flex-wrap justify-center gap-2">
                {selectedStyles.map(styleId => {
                  const style = styleOptions.find(s => s.id === styleId);
                  return (
                    <Badge key={styleId} variant="secondary" className="text-xs">
                      {style?.label}
                    </Badge>
                  );
                })}
              </div>
            </div>
            <Button 
              onClick={handleContinue}
              size="lg"
              variant="hero"
              className="px-8"
            >
              Continue to Closet Scan
              <Sparkles className="w-4 h-4 ml-2" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}