import { useState, useRef, useCallback, useEffect } from 'react';

export interface CameraState {
  isActive: boolean;
  isLoading: boolean;
  error: string | null;
  stream: MediaStream | null;
  hasPermission: boolean;
}

export interface CameraHook {
  cameraState: CameraState;
  videoRef: React.RefObject<HTMLVideoElement>;
  startCamera: () => Promise<void>;
  stopCamera: () => void;
  capturePhoto: () => string | null;
  requestPermission: () => Promise<boolean>;
  clearError: () => void;
}

export function useCamera(): CameraHook {
  const [cameraState, setCameraState] = useState<CameraState>({
    isActive: false,
    isLoading: false,
    error: null,
    stream: null,
    hasPermission: false,
  });

  const videoRef = useRef<HTMLVideoElement>(null);

  const clearError = useCallback(() => {
    setCameraState(prev => ({ ...prev, error: null }));
  }, []);

  const stopCamera = useCallback(() => {
    if (cameraState.stream) {
      cameraState.stream.getTracks().forEach(track => track.stop());
    }
    setCameraState(prev => ({
      ...prev,
      isActive: false,
      stream: null,
      isLoading: false,
    }));
  }, [cameraState.stream]);

  const requestPermission = useCallback(async (): Promise<boolean> => {
    try {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraState(prev => ({
          ...prev,
          error: "Camera is not supported on this device",
          hasPermission: false,
        }));
        return false;
      }

      // Request permission by attempting to get a stream
      const testStream = await navigator.mediaDevices.getUserMedia({ video: true });
      testStream.getTracks().forEach(track => track.stop());
      
      setCameraState(prev => ({ ...prev, hasPermission: true, error: null }));
      return true;
    } catch (error: any) {
      let errorMessage = "Camera access denied";
      
      if (error.name === "NotAllowedError") {
        errorMessage = "Camera permission denied. Please allow camera access in your browser settings.";
      } else if (error.name === "NotFoundError") {
        errorMessage = "No camera found on this device.";
      } else if (error.name === "NotSupportedError") {
        errorMessage = "Camera is not supported on this device.";
      } else if (error.name === "OverconstrainedError") {
        errorMessage = "Camera constraints cannot be satisfied.";
      }

      setCameraState(prev => ({
        ...prev,
        error: errorMessage,
        hasPermission: false,
      }));
      return false;
    }
  }, []);

  const startCamera = useCallback(async () => {
    setCameraState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // First check permission
      const hasPermission = await requestPermission();
      if (!hasPermission) {
        setCameraState(prev => ({ ...prev, isLoading: false }));
        return;
      }

      // Mobile-optimized camera constraints
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: 'environment' }, // Prefer back camera
          width: { ideal: 1280, max: 1920 },
          height: { ideal: 720, max: 1080 },
          aspectRatio: { ideal: 16/9 },
        },
        audio: false,
      };

      console.log('Starting camera with constraints:', constraints);
      let stream: MediaStream;

      try {
        // Try with ideal constraints first
        stream = await navigator.mediaDevices.getUserMedia(constraints);
      } catch (error: any) {
        console.warn('Failed with ideal constraints, trying fallback:', error);
        
        // Fallback to basic constraints
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'environment',
          },
          audio: false,
        });
      }

      console.log('Camera stream acquired:', stream.getVideoTracks()[0]?.getSettings());

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.playsInline = true; // Important for iOS
        videoRef.current.muted = true; // Required for autoplay
        
        // Wait for metadata and start playing
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play()
            .then(() => {
              console.log('Video playback started successfully');
              setCameraState(prev => ({
                ...prev,
                isActive: true,
                isLoading: false,
                stream,
                error: null,
              }));
            })
            .catch((playError) => {
              console.error('Error playing video:', playError);
              setCameraState(prev => ({
                ...prev,
                error: 'Failed to start video playback',
                isLoading: false,
              }));
            });
        };

        videoRef.current.onerror = (event) => {
          console.error('Video element error:', event);
          setCameraState(prev => ({
            ...prev,
            error: 'Video playback error',
            isLoading: false,
          }));
        };
      }

    } catch (error: any) {
      console.error('Camera start error:', error);
      let errorMessage = 'Failed to start camera';
      
      if (error.name === 'NotAllowedError') {
        errorMessage = 'Camera permission denied. Please allow camera access and try again.';
      } else if (error.name === 'NotFoundError') {
        errorMessage = 'No camera found. Please check your device has a working camera.';
      } else if (error.name === 'OverconstrainedError') {
        errorMessage = 'Camera constraints not supported. Your device camera may not support the required features.';
      }

      setCameraState(prev => ({
        ...prev,
        error: errorMessage,
        isLoading: false,
        isActive: false,
      }));
    }
  }, [requestPermission]);

  const capturePhoto = useCallback((): string | null => {
    if (!videoRef.current || !cameraState.isActive) {
      console.error('Cannot capture: video not ready');
      return null;
    }

    try {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        console.error('Cannot get canvas context');
        return null;
      }

      // Set canvas size to video dimensions
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      // Draw the current video frame
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Convert to data URL
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      console.log('Photo captured successfully');
      return dataUrl;

    } catch (error) {
      console.error('Error capturing photo:', error);
      setCameraState(prev => ({
        ...prev,
        error: 'Failed to capture photo',
      }));
      return null;
    }
  }, [cameraState.isActive]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return {
    cameraState,
    videoRef,
    startCamera,
    stopCamera,
    capturePhoto,
    requestPermission,
    clearError,
  };
}