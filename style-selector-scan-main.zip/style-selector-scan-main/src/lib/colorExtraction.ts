// Color extraction utility for analyzing clothing colors from images

export interface ExtractedColors {
  dominant: string;
  palette: string[];
}

// Convert RGB to HEX
function rgbToHex(r: number, g: number, b: number): string {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

// Calculate color distance for clustering
function colorDistance(color1: [number, number, number], color2: [number, number, number]): number {
  const [r1, g1, b1] = color1;
  const [r2, g2, b2] = color2;
  return Math.sqrt((r2 - r1) ** 2 + (g2 - g1) ** 2 + (b2 - b1) ** 2);
}

// K-means clustering for color palette extraction
function kMeansColors(pixels: [number, number, number][], k: number = 5): [number, number, number][] {
  if (pixels.length === 0) return [];
  
  // Initialize centroids randomly
  let centroids: [number, number, number][] = [];
  for (let i = 0; i < k; i++) {
    const randomPixel = pixels[Math.floor(Math.random() * pixels.length)];
    centroids.push([...randomPixel] as [number, number, number]);
  }

  let iterations = 0;
  const maxIterations = 10;

  while (iterations < maxIterations) {
    // Assign pixels to nearest centroid
    const clusters: [number, number, number][][] = Array(k).fill(null).map(() => []);
    
    pixels.forEach(pixel => {
      let minDistance = Infinity;
      let nearestCentroid = 0;
      
      centroids.forEach((centroid, index) => {
        const distance = colorDistance(pixel, centroid);
        if (distance < minDistance) {
          minDistance = distance;
          nearestCentroid = index;
        }
      });
      
      clusters[nearestCentroid].push(pixel);
    });

    // Update centroids
    let converged = true;
    const newCentroids: [number, number, number][] = [];
    
    clusters.forEach((cluster, index) => {
      if (cluster.length === 0) {
        newCentroids.push(centroids[index]);
        return;
      }
      
      const avgR = Math.round(cluster.reduce((sum, pixel) => sum + pixel[0], 0) / cluster.length);
      const avgG = Math.round(cluster.reduce((sum, pixel) => sum + pixel[1], 0) / cluster.length);
      const avgB = Math.round(cluster.reduce((sum, pixel) => sum + pixel[2], 0) / cluster.length);
      
      const newCentroid: [number, number, number] = [avgR, avgG, avgB];
      newCentroids.push(newCentroid);
      
      if (colorDistance(centroids[index], newCentroid) > 5) {
        converged = false;
      }
    });

    centroids = newCentroids;
    if (converged) break;
    iterations++;
  }

  return centroids;
}

// Extract colors from image data URL
export async function extractColorsFromImage(imageDataUrl: string): Promise<ExtractedColors> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        resolve({
          dominant: '#666666',
          palette: ['#666666', '#888888', '#aaaaaa', '#cccccc', '#eeeeee']
        });
        return;
      }

      // Resize image for faster processing
      const maxSize = 150;
      const scale = Math.min(maxSize / img.width, maxSize / img.height);
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const pixels: [number, number, number][] = [];
      
      // Sample pixels (skip some for performance)
      for (let i = 0; i < imageData.data.length; i += 16) { // Skip every 4 pixels
        const r = imageData.data[i];
        const g = imageData.data[i + 1];
        const b = imageData.data[i + 2];
        const a = imageData.data[i + 3];
        
        // Skip transparent or very light/dark pixels
        if (a > 128 && (r + g + b) > 30 && (r + g + b) < 720) {
          pixels.push([r, g, b]);
        }
      }

      if (pixels.length === 0) {
        resolve({
          dominant: '#666666',
          palette: ['#666666', '#888888', '#aaaaaa', '#cccccc', '#eeeeee']
        });
        return;
      }

      // Extract color palette using k-means
      const colorCentroids = kMeansColors(pixels, 6);
      
      // Convert to hex and sort by frequency
      const palette = colorCentroids.map(([r, g, b]) => rgbToHex(r, g, b));
      
      // The most frequent color becomes dominant
      const dominant = palette[0] || '#666666';
      
      resolve({
        dominant,
        palette: palette.slice(0, 5) // Return top 5 colors
      });
    };
    
    img.onerror = () => {
      resolve({
        dominant: '#666666',
        palette: ['#666666', '#888888', '#aaaaaa', '#cccccc', '#eeeeee']
      });
    };
    
    img.src = imageDataUrl;
  });
}