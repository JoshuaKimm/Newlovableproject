import { StylePreference, ScannedItem } from "@/pages/Index";

export interface OutfitRecommendation {
  name: string;
  description: string;
  items: ScannedItem[];
  colorHarmony: string[];
  matchScore: number;
  tags: string[];
}

// Color theory utilities
function hexToHsl(hex: string): [number, number, number] {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
      default: h = 0;
    }
    h /= 6;
  }

  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}

function isComplementary(color1: string, color2: string): boolean {
  const [h1] = hexToHsl(color1);
  const [h2] = hexToHsl(color2);
  const diff = Math.abs(h1 - h2);
  return Math.abs(diff - 180) < 30;
}

function isAnalogous(color1: string, color2: string): boolean {
  const [h1] = hexToHsl(color1);
  const [h2] = hexToHsl(color2);
  const diff = Math.min(Math.abs(h1 - h2), 360 - Math.abs(h1 - h2));
  return diff < 60;
}

function isMonochromatic(colors: string[]): boolean {
  if (colors.length < 2) return true;
  const hues = colors.map(color => hexToHsl(color)[0]);
  const maxDiff = Math.max(...hues) - Math.min(...hues);
  return maxDiff < 30;
}

function calculateColorHarmony(items: ScannedItem[]): number {
  const colors = items.map(item => item.dominantColor);
  if (colors.length < 2) return 0.8;

  let harmonyScore = 0;
  let comparisons = 0;

  for (let i = 0; i < colors.length; i++) {
    for (let j = i + 1; j < colors.length; j++) {
      comparisons++;
      if (isComplementary(colors[i], colors[j])) {
        harmonyScore += 0.9;
      } else if (isAnalogous(colors[i], colors[j])) {
        harmonyScore += 0.7;
      } else {
        harmonyScore += 0.3;
      }
    }
  }

  if (isMonochromatic(colors)) {
    harmonyScore += 0.2;
  }

  return Math.min(harmonyScore / comparisons, 1);
}

function getStyleMultiplier(selectedStyles: StylePreference[], outfitColors: string[]): number {
  let multiplier = 1;
  const [h, s, l] = hexToHsl(outfitColors[0] || '#666666');

  selectedStyles.forEach(style => {
    switch (style) {
      case 'minimalist':
        if (l < 50 && s < 30) multiplier += 0.3;
        break;
      case 'boho':
        if ((h >= 20 && h <= 40) || (h >= 300 && h <= 340)) multiplier += 0.2;
        break;
      case 'preppy':
        if ((h >= 200 && h <= 250) || s > 60) multiplier += 0.25;
        break;
      case 'streetwear':
        if (s > 70 || l < 40) multiplier += 0.3;
        break;
      case 'vintage':
        if (s < 60 && l > 30 && l < 70) multiplier += 0.2;
        break;
      case 'gothic':
        if (l < 30) multiplier += 0.4;
        break;
      case 'romantic':
        if ((h >= 300 && h <= 360) || (h >= 0 && h <= 30)) multiplier += 0.2;
        break;
      case 'sporty':
        if (s > 50 && l > 40) multiplier += 0.2;
        break;
      case 'business':
        if (l < 50 && s < 40) multiplier += 0.35;
        break;
      case 'casual':
        multiplier += 0.1;
        break;
      case 'artsy':
        if (s > 60 || h > 60 && h < 180) multiplier += 0.3;
        break;
      case 'punk':
        if (l < 40 || s > 80) multiplier += 0.4;
        break;
      case 'grunge':
        if (l < 50 && s < 50) multiplier += 0.25;
        break;
      case 'sophisticated':
        if (l < 50 && s < 30) multiplier += 0.35;
        break;
      case 'edgy':
        if (l < 40 || s > 70) multiplier += 0.35;
        break;
      case 'feminine':
        if ((h >= 300 && h <= 360) || s > 50) multiplier += 0.2;
        break;
      case 'masculine':
        if (l < 50 && s < 50) multiplier += 0.25;
        break;
      case 'avant-garde':
        if (s > 80 || h > 180 && h < 280) multiplier += 0.4;
        break;
      case 'retro':
        if (s > 40 && l > 30 && l < 80) multiplier += 0.3;
        break;
      case 'chic':
        if (l > 40 && s < 60) multiplier += 0.3;
        break;
    }
  });

  return multiplier;
}

function generateOutfitName(items: ScannedItem[], selectedStyles: StylePreference[]): string {
  const styleAdjectives: Record<StylePreference, string[]> = {
    minimalist: ['Clean', 'Simple', 'Essential'],
    boho: ['Free-spirited', 'Earthy', 'Flowing'],
    preppy: ['Classic', 'Polished', 'Collegiate'],
    streetwear: ['Urban', 'Fresh', 'Street'],
    vintage: ['Timeless', 'Retro', 'Classic'],
    gothic: ['Dark', 'Dramatic', 'Bold'],
    romantic: ['Soft', 'Dreamy', 'Elegant'],
    sporty: ['Active', 'Dynamic', 'Athletic'],
    business: ['Professional', 'Sharp', 'Executive'],
    casual: ['Relaxed', 'Easy', 'Comfortable'],
    artsy: ['Creative', 'Unique', 'Expressive'],
    punk: ['Rebellious', 'Edgy', 'Bold'],
    grunge: ['Alternative', 'Raw', 'Authentic'],
    sophisticated: ['Refined', 'Elegant', 'Luxe'],
    edgy: ['Modern', 'Daring', 'Contemporary'],
    feminine: ['Graceful', 'Pretty', 'Delicate'],
    masculine: ['Strong', 'Structured', 'Confident'],
    'avant-garde': ['Futuristic', 'Artistic', 'Experimental'],
    retro: ['Nostalgic', 'Vintage', 'Throwback'],
    chic: ['Stylish', 'Effortless', 'Sophisticated']
  };

  const randomStyle = selectedStyles[Math.floor(Math.random() * selectedStyles.length)];
  const adjectives = styleAdjectives[randomStyle];
  const adjective = adjectives[Math.floor(Math.random() * adjectives.length)];

  const colors = items.map(item => hexToHsl(item.dominantColor));
  const avgSaturation = colors.reduce((sum, [,s,]) => sum + s, 0) / colors.length;
  const avgLightness = colors.reduce((sum, [,,l]) => sum + l, 0) / colors.length;

  let descriptor = 'Ensemble';
  if (avgSaturation > 60) descriptor = 'Pop';
  if (avgLightness < 30) descriptor = 'Look';
  if (avgLightness > 70) descriptor = 'Vibe';

  return `${adjective} ${descriptor}`;
}

function generateTags(items: ScannedItem[], selectedStyles: StylePreference[]): string[] {
  const tags: string[] = [...selectedStyles];
  
  const colors = items.map(item => hexToHsl(item.dominantColor));
  const avgSaturation = colors.reduce((sum, [,s,]) => sum + s, 0) / colors.length;
  const avgLightness = colors.reduce((sum, [,,l]) => sum + l, 0) / colors.length;

  if (avgSaturation > 70) tags.push('vibrant');
  if (avgSaturation < 30) tags.push('muted');
  if (avgLightness < 30) tags.push('dark');
  if (avgLightness > 70) tags.push('light');
  
  if (isMonochromatic(items.map(item => item.dominantColor))) {
    tags.push('monochromatic');
  }

  const hasWarmColors = colors.some(([h]) => (h >= 0 && h <= 60) || (h >= 300 && h <= 360));
  const hasCoolColors = colors.some(([h]) => h >= 180 && h <= 240);
  
  if (hasWarmColors) tags.push('autumn', 'spring');
  if (hasCoolColors) tags.push('winter', 'summer');

  return [...new Set(tags)];
}

export function generateOutfitRecommendations(
  scannedItems: ScannedItem[],
  selectedStyles: StylePreference[]
): OutfitRecommendation[] {
  const recommendations: OutfitRecommendation[] = [];
  
  const shirts = scannedItems.filter(item => item.type === 'shirts');
  const jackets = scannedItems.filter(item => item.type === 'jackets');
  const pants = scannedItems.filter(item => item.type === 'pants');
  const shoes = scannedItems.filter(item => item.type === 'shoes');
  const hats = scannedItems.filter(item => item.type === 'hats');

  const combinations: ScannedItem[][] = [];
  
  // Complete outfits with all available pieces
  shirts.forEach(shirt => {
    pants.forEach(pant => {
      const baseCombo = [shirt, pant];
      
      // Add jackets if available
      if (jackets.length > 0) {
        jackets.forEach(jacket => {
          const combo = [...baseCombo, jacket];
          
          // Add shoes if available
          if (shoes.length > 0) {
            shoes.forEach(shoe => combinations.push([...combo, shoe]));
          } else {
            combinations.push(combo);
          }
        });
      } else {
        // Add shoes if available
        if (shoes.length > 0) {
          shoes.forEach(shoe => combinations.push([...baseCombo, shoe]));
        } else {
          combinations.push(baseCombo);
        }
      }
    });
  });

  // Fallback combinations if no complete outfits
  if (combinations.length === 0) {
    scannedItems.forEach(item => {
      combinations.push([item]);
    });
  }

  combinations.forEach(items => {
    const colorHarmonyScore = calculateColorHarmony(items);
    const colors = items.map(item => item.dominantColor);
    const styleMultiplier = getStyleMultiplier(selectedStyles, colors);
    
    let varietyScore = 1;
    if (items.length >= 4) varietyScore = 1.3;
    else if (items.length === 3) varietyScore = 1.2;
    else if (items.length === 2) varietyScore = 1.0;
    else varietyScore = 0.6;

    const finalScore = Math.min((colorHarmonyScore * styleMultiplier * varietyScore), 1);

    if (finalScore > 0.3) {
      recommendations.push({
        name: generateOutfitName(items, selectedStyles),
        description: generateOutfitDescription(items, selectedStyles),
        items,
        colorHarmony: [...new Set([...colors, ...items.flatMap(item => item.colorPalette.slice(0, 2))])].slice(0, 5),
        matchScore: finalScore,
        tags: generateTags(items, selectedStyles)
      });
    }
  });

  return recommendations
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 8);
}

function generateOutfitDescription(items: ScannedItem[], selectedStyles: StylePreference[]): string {
  const styleDescriptions: Record<StylePreference, string> = {
    minimalist: "clean and understated",
    boho: "free-spirited and flowing",
    preppy: "polished and classic",
    streetwear: "urban and trendy",
    vintage: "timeless and nostalgic",
    gothic: "dramatic and bold",
    romantic: "soft and dreamy",
    sporty: "active and comfortable",
    business: "professional and sharp",
    casual: "relaxed and effortless",
    artsy: "creative and expressive",
    punk: "rebellious and edgy",
    grunge: "alternative and authentic",
    sophisticated: "elegant and refined",
    edgy: "modern and daring",
    feminine: "graceful and pretty",
    masculine: "strong and confident",
    'avant-garde': "experimental and artistic",
    retro: "nostalgic and vintage-inspired",
    chic: "stylish and effortless"
  };

  const primaryStyle = selectedStyles[0];
  const baseDescription = styleDescriptions[primaryStyle] || "stylish";

  if (items.length >= 4) {
    return `A complete ${baseDescription} ensemble perfect for making a statement.`;
  } else if (items.length === 3) {
    return `A well-coordinated ${baseDescription} look for any occasion.`;
  } else if (items.length === 2) {
    return `A versatile ${baseDescription} combination that works beautifully together.`;
  } else {
    return `A standout ${baseDescription} piece to build your outfit around.`;
  }
}