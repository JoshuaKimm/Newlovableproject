import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Camera, 
  User, 
  Trash2, 
  Plus, 
  Sparkles, 
  TrendingUp,
  Heart,
  Star,
  Palette,
  ChevronRight,
  Settings,
  Eye,
  MoreHorizontal
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ScannedItem } from '@/pages/Index';
import { getScannedItems, getOutfits, removeScannedItem, removeOutfit, SavedOutfit, addOutfit } from '@/utils/storage';
import { useToast } from '@/hooks/use-toast';

export default function Home() {
  const [scannedItems, setScannedItems] = useState<ScannedItem[]>([]);
  const [savedOutfits, setSavedOutfits] = useState<SavedOutfit[]>([]);
  const [selectedItems, setSelectedItems] = useState<ScannedItem[]>([]);
  const [isCreatingOutfit, setIsCreatingOutfit] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setScannedItems(getScannedItems());
    setSavedOutfits(getOutfits());
  };

  const handleDeleteItem = (itemId: string) => {
    removeScannedItem(itemId);
    setScannedItems(prev => prev.filter(item => item.id !== itemId));
    setSelectedItems(prev => prev.filter(item => item.id !== itemId));
    toast({
      title: "Item removed",
      description: "Clothing item has been deleted from your closet.",
    });
  };

  const handleDeleteOutfit = (outfitId: string) => {
    removeOutfit(outfitId);
    setSavedOutfits(prev => prev.filter(outfit => outfit.id !== outfitId));
    toast({
      title: "Outfit removed",
      description: "Outfit has been deleted from your collection.",
    });
  };

  const toggleItemSelection = (item: ScannedItem) => {
    setSelectedItems(prev => {
      const isSelected = prev.find(selected => selected.id === item.id);
      if (isSelected) {
        return prev.filter(selected => selected.id !== item.id);
      } else {
        return [...prev, item];
      }
    });
  };

  const calculateOutfitScore = (items: ScannedItem[]): number => {
    if (items.length === 0) return 0;
    
    // Simple scoring algorithm based on color harmony
    const colors = items.map(item => item.dominantColor);
    let score = 50; // Base score
    
    // Bonus for having multiple pieces
    if (items.length >= 3) score += 20;
    if (items.length >= 4) score += 10;
    
    // Color harmony scoring (simplified)
    if (colors.length >= 2) {
      const uniqueColors = [...new Set(colors)];
      if (uniqueColors.length === 1) {
        score += 15; // Monochromatic bonus
      } else if (uniqueColors.length === 2) {
        score += 10; // Two-color harmony
      } else if (uniqueColors.length <= 3) {
        score += 5; // Multi-color harmony
      }
    }
    
    // Item type diversity bonus
    const types = [...new Set(items.map(item => item.type))];
    score += types.length * 5;
    
    return Math.min(Math.max(score, 0), 100);
  };

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    if (score >= 40) return 'text-orange-600';
    return 'text-red-600';
  };

  const getScoreBg = (score: number): string => {
    if (score >= 80) return 'bg-green-100 border-green-200';
    if (score >= 60) return 'bg-yellow-100 border-yellow-200';
    if (score >= 40) return 'bg-orange-100 border-orange-200';
    return 'bg-red-100 border-red-200';
  };

  const saveCurrentOutfit = () => {
    if (selectedItems.length === 0) {
      toast({
        title: "No items selected",
        description: "Please select items to create an outfit.",
        variant: "destructive",
      });
      return;
    }

    const score = calculateOutfitScore(selectedItems);
    const outfit: SavedOutfit = {
      id: `outfit_${Date.now()}`,
      name: `Outfit ${savedOutfits.length + 1}`,
      items: [...selectedItems],
      createdAt: new Date().toISOString(),
      score,
    };

    addOutfit(outfit);
    setSavedOutfits(prev => [...prev, outfit]);
    setSelectedItems([]);
    setIsCreatingOutfit(false);
    
    toast({
      title: "Outfit saved!",
      description: `Your outfit scored ${score}/100`,
    });
  };

  const itemsByType = scannedItems.reduce((acc, item) => {
    if (!acc[item.type]) acc[item.type] = [];
    acc[item.type].push(item);
    return acc;
  }, {} as Record<string, ScannedItem[]>);

  const currentScore = calculateOutfitScore(selectedItems);

  return (
    <div className="min-h-screen bg-gradient-hero">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12">
              <AvatarFallback className="bg-primary text-primary-foreground">
                <User className="w-6 h-6" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold text-primary-foreground">Your Closet</h1>
              <p className="text-primary-foreground/70">
                {scannedItems.length} items • {savedOutfits.length} outfits saved
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-primary-foreground hover:bg-white/10"
            >
              <Settings className="w-5 h-5" />
            </Button>
            <Button 
              onClick={() => navigate('/')}
              className="bg-white/10 text-primary-foreground hover:bg-white/20"
            >
              <Camera className="w-4 h-4 mr-2" />
              Scan More
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Closet Items */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <TrendingUp className="w-8 h-8 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold">{scannedItems.length}</div>
                  <div className="text-sm text-muted-foreground">Items</div>
                </CardContent>
              </Card>
              
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Heart className="w-8 h-8 text-pink-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{savedOutfits.length}</div>
                  <div className="text-sm text-muted-foreground">Outfits</div>
                </CardContent>
              </Card>
              
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Star className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {savedOutfits.length > 0 ? Math.round(savedOutfits.reduce((acc, outfit) => acc + (outfit.score || 0), 0) / savedOutfits.length) : 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Avg Score</div>
                </CardContent>
              </Card>
              
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Palette className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {[...new Set(scannedItems.map(item => item.dominantColor))].length}
                  </div>
                  <div className="text-sm text-muted-foreground">Colors</div>
                </CardContent>
              </Card>
            </div>

            {/* Closet Items by Category */}
            {Object.keys(itemsByType).length === 0 ? (
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardContent className="p-8 text-center">
                  <Camera className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Your closet is empty</h3>
                  <p className="text-muted-foreground mb-4">
                    Start scanning your clothes to build your digital wardrobe
                  </p>
                  <Button onClick={() => navigate('/')}>
                    <Camera className="w-4 h-4 mr-2" />
                    Start Scanning
                  </Button>
                </CardContent>
              </Card>
            ) : (
              Object.entries(itemsByType).map(([type, items]) => (
                <Card key={type} className="bg-white/90 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="capitalize">{type}</span>
                      <Badge variant="secondary">{items.length} items</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {items.map((item) => (
                        <div 
                          key={item.id} 
                          className={`relative group cursor-pointer transition-all duration-200 ${
                            selectedItems.find(selected => selected.id === item.id) 
                              ? 'ring-2 ring-primary' 
                              : ''
                          }`}
                          onClick={() => toggleItemSelection(item)}
                        >
                          <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-2">
                            <img 
                              src={item.image} 
                              alt={`${item.type} item`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-4 h-4 rounded-full border-2 border-gray-300"
                                style={{ backgroundColor: item.dominantColor }}
                              />
                              <div className="flex gap-1">
                                {item.colorPalette.slice(0, 3).map((color, idx) => (
                                  <div
                                    key={idx}
                                    className="w-2 h-2 rounded-full"
                                    style={{ backgroundColor: color }}
                                  />
                                ))}
                              </div>
                            </div>
                            
                            <Button
                              variant="ghost"
                              size="icon"
                              className="opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteItem(item.id);
                              }}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Outfit Builder & Saved Outfits */}
          <div className="space-y-6">
            {/* Outfit Builder */}
            <Card className="bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Create Outfit
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedItems.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Style Score</span>
                      <Badge 
                        variant="outline" 
                        className={`${getScoreBg(currentScore)} ${getScoreColor(currentScore)}`}
                      >
                        {currentScore}/100
                      </Badge>
                    </div>
                    <Progress value={currentScore} className="h-2" />
                    
                    <div className="grid grid-cols-3 gap-2">
                      {selectedItems.map((item) => (
                        <div key={item.id} className="aspect-square bg-gray-100 rounded-md overflow-hidden">
                          <img 
                            src={item.image} 
                            alt={`Selected ${item.type}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Button 
                    onClick={saveCurrentOutfit} 
                    disabled={selectedItems.length === 0}
                    className="w-full"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Save Outfit
                  </Button>
                  
                  {selectedItems.length > 0 && (
                    <Button 
                      variant="outline" 
                      onClick={() => setSelectedItems([])}
                      className="w-full"
                    >
                      Clear Selection
                    </Button>
                  )}
                </div>
                
                <div className="text-xs text-muted-foreground">
                  Select items from your closet to create and score outfits
                </div>
              </CardContent>
            </Card>

            {/* Saved Outfits */}
            <Card className="bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Saved Outfits</span>
                  <Badge variant="secondary">{savedOutfits.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {savedOutfits.length === 0 ? (
                    <div className="text-center py-8">
                      <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">
                        No saved outfits yet
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {savedOutfits.map((outfit) => (
                        <div key={outfit.id} className="group">
                          <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                            <div className="grid grid-cols-2 gap-1 w-16 h-16">
                              {outfit.items.slice(0, 4).map((item, idx) => (
                                <div key={idx} className="aspect-square bg-gray-100 rounded-sm overflow-hidden">
                                  <img 
                                    src={item.image} 
                                    alt={item.type}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              ))}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="font-medium truncate">{outfit.name}</h4>
                                <Badge 
                                  variant="outline" 
                                  className={`text-xs ${getScoreBg(outfit.score || 0)} ${getScoreColor(outfit.score || 0)}`}
                                >
                                  {outfit.score}/100
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground mb-2">
                                {outfit.items.length} items • {new Date(outfit.createdAt).toLocaleDateString()}
                              </p>
                              <div className="flex items-center gap-1">
                                {[...new Set(outfit.items.map(item => item.dominantColor))].slice(0, 4).map((color, idx) => (
                                  <div
                                    key={idx}
                                    className="w-3 h-3 rounded-full border border-gray-300"
                                    style={{ backgroundColor: color }}
                                  />
                                ))}
                              </div>
                            </div>
                            
                            <Button
                              variant="ghost"
                              size="icon"
                              className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                              onClick={() => handleDeleteOutfit(outfit.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          {savedOutfits.length > 1 && <Separator className="my-2" />}
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}