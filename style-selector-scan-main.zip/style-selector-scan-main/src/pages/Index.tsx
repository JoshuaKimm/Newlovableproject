import { useState } from "react";
import { StyleSelector } from "@/components/StyleSelector";
import { ClosetScanner } from "@/components/ClosetScanner";
import { OutfitRecommendations } from "@/components/OutfitRecommendations";
import { Button } from "@/components/ui/button";
import { Sparkles, Camera, Shirt } from "lucide-react";

export type StylePreference = 
  | "minimalist" | "boho" | "preppy" | "streetwear" | "vintage" | "gothic" 
  | "romantic" | "sporty" | "business" | "casual" | "artsy" | "punk"
  | "grunge" | "sophisticated" | "edgy" | "feminine" | "masculine" 
  | "avant-garde" | "retro" | "chic";

export type ClothingType = "shirts" | "jackets" | "pants" | "shoes" | "hats";

export interface ScannedItem {
  id: string;
  type: ClothingType;
  dominantColor: string;
  colorPalette: string[];
  image: string;
}

const Index = () => {
  const [currentStep, setCurrentStep] = useState<"welcome" | "styles" | "scanning" | "recommendations">("welcome");
  const [selectedStyles, setSelectedStyles] = useState<StylePreference[]>([]);
  const [scannedItems, setScannedItems] = useState<ScannedItem[]>([]);
  const [currentScanType, setCurrentScanType] = useState<ClothingType>("shirts");

  const handleStylesSelected = (styles: StylePreference[]) => {
    setSelectedStyles(styles);
    setCurrentStep("scanning");
  };

  const handleItemScanned = (item: ScannedItem) => {
    setScannedItems(prev => [...prev, item]);
  };

  const handleScanningComplete = () => {
    setCurrentStep("recommendations");
  };

  const resetApp = () => {
    setCurrentStep("welcome");
    setSelectedStyles([]);
    setScannedItems([]);
    setCurrentScanType("shirts");
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      <div className="container mx-auto px-4 py-8">
        {currentStep === "welcome" && (
          <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
            <div className="animate-float mb-8">
              <div className="relative">
                <Sparkles className="w-16 h-16 text-primary-glow mx-auto mb-4" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-accent rounded-full animate-pulse" />
              </div>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary-foreground via-accent to-primary-foreground bg-clip-text text-transparent mb-6 animate-fade-in">
              StyleScan
            </h1>
            
            <p className="text-xl text-primary-foreground/80 mb-8 max-w-2xl animate-slide-up">
              Discover perfect outfit combinations by scanning your closet. 
              AI-powered color analysis meets your personal style preferences.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 items-center animate-slide-up">
              <Button 
                variant="hero" 
                size="hero"
                onClick={() => setCurrentStep("styles")}
                className="group"
              >
                <Camera className="w-6 h-6 group-hover:scale-110 transition-transform" />
                Start Scanning
              </Button>
              
              <div className="flex items-center gap-2 text-primary-foreground/60 text-sm">
                <Shirt className="w-4 h-4" />
                <span>Shirts → Jackets → Pants</span>
              </div>
            </div>
          </div>
        )}

        {currentStep === "styles" && (
          <StyleSelector 
            onStylesSelected={handleStylesSelected}
          />
        )}

        {currentStep === "scanning" && (
          <ClosetScanner
            selectedStyles={selectedStyles}
            currentScanType={currentScanType}
            onCurrentScanTypeChange={setCurrentScanType}
            onItemScanned={handleItemScanned}
            onComplete={handleScanningComplete}
            scannedItems={scannedItems}
          />
        )}

        {currentStep === "recommendations" && (
          <OutfitRecommendations
            scannedItems={scannedItems}
            selectedStyles={selectedStyles}
            onReset={resetApp}
            onRescan={() => setCurrentStep("scanning")}
          />
        )}
      </div>
    </div>
  );
};

export default Index;
