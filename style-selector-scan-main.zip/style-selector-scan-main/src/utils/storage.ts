import { ScannedItem } from "@/pages/Index";

const STORAGE_KEYS = {
  SCANNED_ITEMS: 'styleScan_scannedItems',
  USER_STYLES: 'styleScan_userStyles',
  OUTFITS: 'styleScan_outfits',
} as const;

export interface SavedOutfit {
  id: string;
  name: string;
  items: ScannedItem[];
  createdAt: string;
  score?: number;
}

// Scanned Items Storage
export function saveScannedItems(items: ScannedItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SCANNED_ITEMS, JSON.stringify(items));
    console.log('Saved scanned items:', items.length);
  } catch (error) {
    console.error('Failed to save scanned items:', error);
  }
}

export function getScannedItems(): ScannedItem[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.SCANNED_ITEMS);
    if (!stored) return [];
    
    const items = JSON.parse(stored);
    console.log('Loaded scanned items:', items.length);
    return items;
  } catch (error) {
    console.error('Failed to load scanned items:', error);
    return [];
  }
}

export function addScannedItem(item: ScannedItem): void {
  const items = getScannedItems();
  items.push(item);
  saveScannedItems(items);
}

export function removeScannedItem(itemId: string): void {
  const items = getScannedItems();
  const filtered = items.filter(item => item.id !== itemId);
  saveScannedItems(filtered);
}

// Outfits Storage
export function saveOutfits(outfits: SavedOutfit[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.OUTFITS, JSON.stringify(outfits));
    console.log('Saved outfits:', outfits.length);
  } catch (error) {
    console.error('Failed to save outfits:', error);
  }
}

export function getOutfits(): SavedOutfit[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.OUTFITS);
    if (!stored) return [];
    
    const outfits = JSON.parse(stored);
    console.log('Loaded outfits:', outfits.length);
    return outfits;
  } catch (error) {
    console.error('Failed to load outfits:', error);
    return [];
  }
}

export function addOutfit(outfit: SavedOutfit): void {
  const outfits = getOutfits();
  outfits.push(outfit);
  saveOutfits(outfits);
}

export function removeOutfit(outfitId: string): void {
  const outfits = getOutfits();
  const filtered = outfits.filter(outfit => outfit.id !== outfitId);
  saveOutfits(filtered);
}

// User Styles Storage
export function saveUserStyles(styles: string[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_STYLES, JSON.stringify(styles));
    console.log('Saved user styles:', styles);
  } catch (error) {
    console.error('Failed to save user styles:', error);
  }
}

export function getUserStyles(): string[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.USER_STYLES);
    if (!stored) return [];
    
    const styles = JSON.parse(stored);
    console.log('Loaded user styles:', styles);
    return styles;
  } catch (error) {
    console.error('Failed to load user styles:', error);
    return [];
  }
}

// Clear all data
export function clearAllData(): void {
  try {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
    console.log('Cleared all storage data');
  } catch (error) {
    console.error('Failed to clear storage data:', error);
  }
}